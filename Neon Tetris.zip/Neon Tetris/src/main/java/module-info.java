module com.example.neontetris {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.neontetris to javafx.fxml;
    exports com.example.neontetris;
}